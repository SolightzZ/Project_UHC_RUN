import "./System_team";
import "./deaths";
import "./kills";
import "./random";
import "./UseItems";
import "./nametag";
import "./sounds_bow";
import "./chat";
import "./WorldBorder"; // loop
import "./Auto_Smelt"; // loop 10
import "./clearitems"; // loop 20

import "./uhc/main"; // loop 20
import "./uhc/start"; // loop 20
//import "./uhc/display"; //loop

console.warn(" +++  Scripts API Succeeds +++");
